from graphics_init import *

# triggers

class map_change_trigger(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.triggers
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.grass.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
class struct_trigger(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.triggers
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.struct_trigger.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y


# tiles

class block(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.stonebricks.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
class woodengate(pygame.sprite.Sprite):
	
    def __init__(self, game, x, y):
	
        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.gatesprite.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class grass(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = ground_layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.grass.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
class marbletile(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = ground_layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize
        
        self.image = self.game.marbletilesprite.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
class wooden_floor(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = ground_layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.woodfloorsprite.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
		
class blue_wall_hor(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(0, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class blue_wall_ver_right(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(64, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class blue_wall_ver_left(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(96, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class blue_wall_top_right(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(128, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class blue_wall_top_left(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(160, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class blue_wall_bottom_right(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(192, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class blue_wall_bottom_left(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(224, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y

class blue_wall_hor(pygame.sprite.Sprite):
	
	def __init__(self, game, x, y):
	
		self.game = game
		self._layer = ground_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = TileSize
		self.height = TileSize
		
		self.image = self.game.bluewallsprite.get_sprite(0, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class voidblock(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = ground_layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        
        self.width = TileSize
        self.height = TileSize

        self.image = self.game.void.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
# misc

class house(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = 128
        self.height = 128

        self.image = self.game.house.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
class medcabinet(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.healing_tiles
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = 64
        self.height = 64

        self.image = self.game.medcabinetsprite.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
class bed(pygame.sprite.Sprite):

	def __init__(self, game, x, y):

		self.game = game
		self._layer = block_layer
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TileSize
		self.y = y * TileSize
		self.width = 64
		self.height = 32

		self.image = self.game.bedsprite.get_sprite(0, 0, self.width, self.height)

		self.rect = self.image.get_rect()
		self.rect.x = self.x
		self.rect.y = self.y
		
class tree(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        self.game = game
        self._layer = block_layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize
        self.width = 96
        self.height = 96

        self.image = self.game.treesprite.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
