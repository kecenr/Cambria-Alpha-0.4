# testbuild0.4.2

Alpha 0.4

CHANGELOG:

Combat

-Added HP system for player and rovers
-Added health bar for rovers
-Added rover knockback

Town

-Added dialogue system
-Added clinic, shop, bar, town hall
-Added shopkeeper, mayor, and bartender NPC

Terrain

-Added trees
-Added paths

Map layout

-Added town
-Added forest

Miscellaneous

-Added mute (M) and unmute (U) button
-Added developer console
