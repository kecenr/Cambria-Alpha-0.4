from graphics_init import *

class medic(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = foe_layer
        self.groups = self.game.npc, self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)
        pygame.mixer.pre_init(44100, 16, 2, 32) #frequency, size, channels, buffersize
        
        self.x = x * TileSize
        self.y = y * TileSize
        self.x_change = 0
        self.y_change = 0
        self.x_change_orig = 0
        self.y_change_orig = 0
        self.facing = 'down'

        self.idle = 300
        self.stopped = False
        self.busy = False
        self.move = TileSize
        self.idlepoint = 1
        self.an_loop = 0

        self.width = TileSize
        self.height = TileSize

        self.image = self.game.doctorspritesheet.get_sprite(0, 0, 32, 32)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        self.max_travel = random.randint(32, 64)
        self.move_loop = 0

    def dialogue(self):
        self.stopped = True
        if self.busy:
            return "Medic: Sorry I'm resting right now."
        else:
            return "Medic: Let me know if you're feeling unwell."
            
    def endDialogue(self):
        self.stopped = False
        self.x_change = self.x_change_orig
        self.y_change = self.y_change_orig
        self.x_change_orig = 0
        self.y_change_orig = 0

    def collide(self):
        if self.game.hp < 150:
            self.game.hp += 1

    def update(self):
        self.movement()
        self.animation()
        if self.move:
            self.rect.x += self.x_change
            self.collision('x')
            self.rect.y += self.y_change
            self.collision('y')

    def movement(self):

        x = int(self.rect.x / TileSize)
        y = int(self.rect.y / TileSize)

        if self.stopped:
            if not self.x_change_orig and not self.y_change_orig:
                self.x_change_orig = self.x_change
                self.y_change_orig = self.y_change
                self.x_change = 0
                self.y_change = 0
            return

        if self.idle:
            self.idle -= 1
        elif self.move:
            self.move -= 1
        elif x == 30 and y == 11:
            if self.idlepoint == 3:
                self.idle = 300
                self.idlepoint = 1
            else:
                self.move = TileSize
                self.facing = 'up'
                self.x_change = 0
                self.y_change = -1
        elif x == 30 and y == 10:
            self.move = TileSize * 21
            self.facing = 'left'
            self.y_change = 0
            self.x_change = -1
        elif x == 9 and y == 10:
            self.move = TileSize * 3
            self.facing = 'down'
            self.y_change = 1
            self.x_change = 0
        elif x == 9 and y == 13:
            self.busy = True
            if self.idlepoint == 1:
                self.idle = 300
                self.idlepoint = 2
            else:
                self.move = TileSize * 9
                self.facing = 'up'
                self.y_change = -1
                self.x_change = 0
        elif x == 9 and y == 4:
            if self.idlepoint == 2:
                self.idle = 300
                self.idlepoint = 3
            else:
                self.busy = False
                self.move = TileSize * 21
                self.facing = 'right'
                self.y_change = 0
                self.x_change = 1
        elif x == 30 and y == 4:
            self.move = TileSize * 7
            self.facing = 'down'
            self.y_change = 1
            self.x_change = 0

    def collision(self, direction):
        if direction == 'x':
            hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
            if hits:
                if self.x_change > 0:
                    self.rect.x = hits[0].rect.left - self.rect.width
                    self.facing = 'left'
                if self.x_change < 0:
                    self.rect.x = hits[0].rect.right
                    self.facing = 'right'

        if direction == 'y':
            hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
            if hits:
                if self.y_change > 0:
                    self.rect.y = hits[0].rect.top - self.rect.height
                    self.facing = 'up'
                if self.y_change < 0:
                    self.rect.y = hits[0].rect.bottom
                    self.facing = 'down'
                                            
    def animation(self):

        right_walk = [self.game.doctorspritesheet.get_sprite(64, 0, self.width, self.height), # left foot
                        self.game.doctorspritesheet.get_sprite(32, 0, self.width, self.height)] # right foot

        left_walk = [self.game.doctorspritesheet.get_sprite(128, 0, self.width, self.height), # left foot
                        self.game.doctorspritesheet.get_sprite(160, 0, self.width, self.height)] # right foot

        down_walk = [self.game.doctorspritesheet.get_sprite(224, 0, self.width, self.height), # left foot
                        self.game.doctorspritesheet.get_sprite(256, 0, self.width, self.height)] # right foot

        up_walk = [self.game.doctorspritesheet.get_sprite(320, 0, self.width, self.height), # left foot
                    self.game.doctorspritesheet.get_sprite(352, 0, self.width, self.height)] # right foot

        if self.facing == 'right':
            if self.x_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = right_walk[math.floor(self.an_loop)]
                self.an_loop += 0.05 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

        if self.facing == 'left':
            if self.x_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(96, 0, self.width, self.height)
            else:
                self.image = left_walk[math.floor(self.an_loop)]
                self.an_loop += 0.05 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

        if self.facing == 'down':
            if self.y_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(192, 0, self.width, self.height)
            else:
                self.image = down_walk[math.floor(self.an_loop)]
                self.an_loop += 0.05 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

        if self.facing == 'up':
            if self.y_change == 0:
                self.image = self.game.doctorspritesheet.get_sprite(288, 0, self.width, self.height)
            else:
                self.image = up_walk[math.floor(self.an_loop)]
                self.an_loop += 0.05 # determines animation speed
                if self.an_loop >= 2: # resets the animation
                    self.an_loop = 0

