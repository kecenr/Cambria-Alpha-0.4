from graphics_init import *

class rover(pygame.sprite.Sprite):

    def __init__(self, game, x, y):

        # initialisation
        self.game = game
        self._layer = foe_layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        # position and size
        self.x = x * TileSize
        self.y = y * TileSize
        self.width = TileSize
        self.height = TileSize

        # movement
        self.x_change = 0
        self.y_change = 0
        self.directions = ['left', 'right', 'swdash', 'nwdash', 'nedash', 'sedash', 'idle']
        self.facing = random.choice(self.directions)
        self.move_loop = 0
        self.max_idle = 100
        self.max_travel = random.randint(32, 128)
        self.max_dash = random.randint(32, 64)
        self.max_knockback = random.randint(32, 64)

        # render
        self.image = self.game.roverspritesheet.get_sprite(0, 0, self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
        # damage
        self.hp = 20
        self.dmg_timer = 0
        self.hb = rover_healthbar(self, game, x, y)
        
        # loading sounds
        self.roverdeath = pygame.mixer.Sound('soundfiles/roverdeath.ogg')
        self.roverdestruction = pygame.mixer.Sound('soundfiles/roverdestruction.ogg')

    def update(self):
        self.movement()
        self.animation()
        self.collision()
        self.melee_collision()
        self.rect.x += self.x_change
        self.rect.y += self.y_change

    def movement(self):
        max = self.max_travel

        if self.facing == 'left':
            self.x_change = -RoverVel

        elif self.facing  == 'right':
            self.x_change = RoverVel

        elif self.facing  == 'swdash':
            self.x_change = -RoverDashVel
            self.y_change = RoverDashVel
            max = self.max_dash

        elif self.facing  == 'sedash':
            self.x_change = RoverDashVel
            self.y_change = RoverDashVel
            max = self.max_dash

        elif self.facing  == 'nwdash':
            self.x_change = -RoverDashVel
            self.y_change = -RoverDashVel
            max = self.max_dash

        elif self.facing  == 'nedash':
            self.x_change = RoverDashVel
            self.y_change = -RoverDashVel
            max = self.max_dash

        elif self.facing == 'idle':
            self.x_change = 0
            self.y_change = 0
            max = self.max_idle

        self.move_loop += 1
        if self.move_loop >= max:
            self.move_loop = 0
            self.facing = random.choice(self.directions)

    def animation(self):
        if self.facing == 'right' or self.facing == 'nedash' or self.facing == 'sedash':
            self.image = self.game.roverspritesheet.get_sprite(32, 0, self.width, self.height)
        elif self.facing == 'left' or self.facing == 'swdash' or self.facing == 'nwdash':
            self.image = self.game.roverspritesheet.get_sprite(64, 0, self.width, self.height)
        elif self.facing == 'idle':
            self.image = self.game.roverspritesheet.get_sprite(0, 0, self.width, self.height)

    def collision(self):
        # credit to belambic for coding most of this
        hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
        out_of_bounds = pygame.sprite.spritecollide(self, self.game.triggers, False)
        if hits or out_of_bounds:
            self.move_loop = 0
            if self.x_change < 0:
                if self.y_change < 0:
                    self.facing = random.choice(['right', 'sedash'])
                elif self.y_change == 0:
                    self.facing = random.choice(['right', 'nedash', 'sedash'])
                elif self.y_change > 0:
                    self.facing = random.choice(['right', 'nedash'])
            elif self.x_change > 0:
                if self.y_change < 0:
                    self.facing = random.choice(['left', 'swdash'])
                elif self.y_change == 0:
                    self.facing = random.choice(['left', 'nwdash', 'swdash'])
                elif self.y_change > 0:
                    self.facing = random.choice(['left', 'nwdash'])
            self.x_change = -self.x_change
            self.y_change = -self.y_change
            
    def melee_collision(self):

        if self.dmg_timer > 0:
            self.dmg_timer -= 1

        hits = pygame.sprite.spritecollide(self, self.game.weapons, False)
        
        if hits:
        
            if self.hp < 20:
                self.hb.status()
        
            if self.dmg_timer == 0:
                self.roverdeath.play()
                self.hp -= random.randint(3, 7)
                self.knockback()
                if self.hp > 0:
                    self.dmg_timer = 20  

            if self.hp <= 0:
                print('user killed rover')
                print(self.game.rovers, 'rovers remaining')
                self.roverdestruction.play()
                self.game.rovers -= 1
                self.kill()
                self.game.conditionMet()

                if self.game.rovers == 1:
                    print('one rover remains! kill it!')

    def knockback(self):
    
        if self.game.player.facing == 'left':

            self.x_change -= 6
            self.y_change += random.randint(-1, 1)
            self.move_loop += 1
            if self.move_loop >= self.max_knockback:
                self.facing = 'idle'
        if self.game.player.facing == 'right':
            self.x_change += 6
            self.y_change += random.randint(-1, 1)
            self.move_loop += 1
            if self.move_loop >= self.max_knockback:
                self.facing = 'idle'
        if self.game.player.facing == 'up':
            self.x_change += random.randint(-1, 1)
            self.y_change -= 6
            self.move_loop += 1
            if self.move_loop >= self.max_knockback:
                self.facing = 'idle'
        if self.game.player.facing == 'down':
            self.x_change += random.randint(-1, 1)
            self.y_change += 6
            self.move_loop += 1
            if self.move_loop >= self.max_knockback:
                self.facing = 'idle'

            self.x_change = -8
            self.y_change = random.randint(-1, 1)
        elif self.game.player.facing == 'right':
            self.x_change = 8
            self.y_change = random.randint(-1, 1)
        elif self.game.player.facing == 'up':
            self.x_change = random.randint(-1, 1)
            self.y_change = -8
        elif self.game.player.facing == 'down':
            self.x_change = random.randint(-1, 1)
            self.y_change = 8

        self.move_loop += 1
        if self.move_loop >= self.max_knockback:
            self.move_loop = 0
            self.facing = random.choice(['left', 'right', 'sedash', 'nedash', 'swdash', 'idle'])

class rover_healthbar(pygame.sprite.Sprite):

    def __init__(self, rover, game, x, y):

        self.game = game
        self.rover = rover
        self._layer = foe_layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * TileSize
        self.y = y * TileSize - 20
        self.width = TileSize
        self.height = TileSize

        self.x_change = self.rover.x_change
        self.y_change = self.rover.y_change

        self.image = self.game.healthbarsprite.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
    def update(self):
        self.status()
        self.rect.x += self.rover.x_change
        self.rect.y += self.rover.y_change
        
    def status(self):
    
        if self.rover.hp < 20 and self.rover.hp > 17:
            self.image = self.game.healthbarsprite.get_sprite(32, 0, self.width, self.height)

        elif self.rover.hp < 17 and self.rover.hp > 12:
            self.image = self.game.healthbarsprite.get_sprite(64, 0, self.width, self.height)
        
        elif self.rover.hp < 12 and self.rover.hp > 7:
            self.image = self.game.healthbarsprite.get_sprite(96, 0, self.width, self.height)
 
        elif self.rover.hp < 7 and self.rover.hp > 0:
            self.image = self.game.healthbarsprite.get_sprite(128, 0, self.width, self.height)
        
        elif self.rover.hp <= 0:
            self.kill()
